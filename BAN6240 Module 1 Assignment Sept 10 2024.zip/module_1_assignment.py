
"""Module_1_Assignment_.ipynb


"""

import random

# List of names and genders
Employee_names = ["Micah", "Salome", "Daniel", "Emmaculate", "Leon", "Lydia", "James",
                  "Jennifer","James","Jane", "Alice", "Bernand", "Charles", "Evelyn","etc"]

# List of genders
gender = ["Female","Male"]

# Generate 400 workers with random attributes

workers = [{"Employee_names": random.choice(Employee_names),

            # Random salary between 5,000 to 30,000 dollars

            "Employee_salary": random.randint(5000, 30000),

            "Employee_gender": random.choice(gender)}

           for _ in range(400)]

# Loop through each worker to create payment slips

for worker in workers:
    name = worker["Employee_names"]

    salary = worker["Employee_salary"]

    gender = worker["Employee_gender"]

    try:
        # Conditional assignment of employee level

        if 10000 < salary < 20000:

            worker['Employee_Level'] = 'A1'


        elif 7500 < salary < 30000 and gender == "Female":

            worker['Employee_Level'] = 'A5-F'


        else:
            worker['Employee_Level'] = 'Unknown'

        print(f"Payment Slip for {name}:")

        print(f"  Salary: ${salary}")

        print(f"  Gender: {gender}")

        print(f"  Employee Level: {worker['Employee_Level']}")



    except Exception as e:
        print(f"Error processing payment slip for {name}: {str(e)}")
