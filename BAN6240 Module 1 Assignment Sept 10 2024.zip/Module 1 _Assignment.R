
# Define lists of names
Employee_names <- c("Micah", "Salome", "Daniel", "Emmaculate", "Leon", "Lydia", "James", 
                    "Jennifer","James", "Jane", "Alice", "Bernand", "Charles", "Evelyn","etc")

# Define lists of genders

Employee_gender <- c("Male", "Female")

# Generate 400 workers with random names,genders and salaries

workers <- data.frame(
  
  Employee_names <- sample(Employee_names, 400, replace = TRUE),
  
  salary <- sample(5000:30000, 400, replace = TRUE),
  
  gender <- sample(Employee_gender, 400, replace = TRUE)
  
)

#print(workers)

# Loop in workers dataframe 

for (i in 1:nrow(workers)) {
  
  salary <- workers$salary[i]
  
  gender <- workers$gender[i]
  
  tryCatch({
    if (salary > 10000 & salary < 20000) {
      
      workers$Employee_Level[i] <- 'A1'
      
    } else if (salary > 7500 & salary < 30000 & gender == "Female") {
      
      workers$Employee_Level[i] <- 'A5-F'
      
    } else {
      workers$Employee_Level[i] <- 'Unknown'
    }
    
    print(paste("Payment Slip for this Employee", workers$Employee_names[i]))
    
    print(paste(" Employee Salary:", salary))
    
    print(paste(" Employee Gender:", gender))
    
    print(paste(" Employee Level:", workers$Employee_Level[i]))
    
    
  }, error = function(e) {
    
    print(paste("Error processing payment slip for", workers$Employee_names[i], ":", e$message))
    
    
    
  })
}

